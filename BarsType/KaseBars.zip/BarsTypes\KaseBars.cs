﻿// 
// Copyright (C) 2021, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.ComponentModel;
using NinjaTrader;
using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.BarsTypes
{
	public class KaseBarsType : BarsType
	{
		public override void ApplyDefaultBasePeriodValue(BarsPeriod period) { }

		public override void ApplyDefaultValue(BarsPeriod period)
		{
			period.Value = 4;
		}

		public override string ChartLabel(DateTime time)
		{
			return time.ToString("T", Core.Globals.GeneralOptions.CurrentCulture);
		}

		public override int GetInitialLookBackDays(BarsPeriod barsPeriod, TradingHours tradingHours, int barsBack) { return 1; }

		public override double GetPercentComplete(Bars bars, DateTime now) { return 0; }

		protected override void OnDataPoint(Bars bars, double open, double high, double low, double close, DateTime time, long volume, bool isBar, double bid, double ask)
		{
			if (SessionIterator == null)
				SessionIterator = new SessionIterator(bars);

			bool isNewSession = SessionIterator.IsNewSession(time, isBar);
			if (isNewSession)
				SessionIterator.GetNextSession(time, isBar);
			if (bars.Count == 0 || bars.IsResetOnNewTradingDay && isNewSession)
				AddBar(bars, open, high, low, close, time, volume);
			else
			{
				double barClose = bars.GetClose(bars.Count - 1);
				double barHigh = bars.GetHigh(bars.Count - 1);
				double barLow = bars.GetLow(bars.Count - 1);
				double tickSize = bars.Instrument.MasterInstrument.TickSize;
				double rangeValue = Math.Floor(10000000.0 * bars.BarsPeriod.Value * tickSize) / 10000000.0;

				// calc true range using new tick to see if bar will exceed target range
				double prevClose = bars.Count < 2 ? barClose : bars.GetClose(bars.Count - 2);
				double hi = Math.Max(Math.Max(barHigh, close), prevClose);
				double lo = Math.Min(Math.Min(barLow, close), prevClose);
				double trueRange = hi - lo;


				if (bars.Instrument.MasterInstrument.Compare(trueRange, rangeValue) > 0)
				{					
					AddBar(bars, close, close, close, close, time, volume);
				}
				else
				{
					UpdateBar(bars, close > barHigh ? close : barHigh, close < barLow ? close : barLow, close, time, volume);
				}
			}
			bars.LastPrice = close;
		}

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				//Name = Custom.Resource.NinjaScriptBarsTypeRange;
				Description = "KaseBars";
				Name = "Kase Bars";
				BuiltFrom = BarsPeriodType.Tick;
				//BarsPeriod = new BarsPeriod { BarsPeriodType = BarsPeriodType.Range };
				BarsPeriod = new BarsPeriod { BarsPeriodType = (BarsPeriodType)100, BarsPeriodTypeName = "KaseBars", Value = 1 };
				DaysToLoad = 3;
				IsIntraday = true;
				IsTimeBased = false;
			}
			else if (State == State.Configure)
			{
				Name = string.Format(Core.Globals.GeneralOptions.CurrentCulture, "Kase Bars", BarsPeriod.Value, BarsPeriod.MarketDataType != MarketDataType.Last ? string.Format(" - {0}", Core.Globals.ToLocalizedObject(BarsPeriod.MarketDataType, Core.Globals.GeneralOptions.CurrentUICulture)) : string.Empty);

				Properties.Remove(Properties.Find("BaseBarsPeriodType", true));
				Properties.Remove(Properties.Find("BaseBarsPeriodValue", true));
				Properties.Remove(Properties.Find("PointAndFigurePriceType", true));
				Properties.Remove(Properties.Find("ReversalType", true));
				Properties.Remove(Properties.Find("Value2", true));
			}
		}
	}
}
